﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ПР_13.Classes;

namespace ПР_13
{
    /// <summary>
    /// Логика взаимодействия для WindowAdd.xaml
    /// </summary>
    public partial class WindowAdd : Window
    {
        public WindowAdd()
        {
            InitializeComponent();
        }

        private void BtnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            Student price = new Student()
            {
            fio = TxtName.Text,
            Group = txtgroup.Text,
            math = int.Parse(txtMath.Text),
            rus = int.Parse(txtRus.Text),
            xim = int.Parse(txtXim.Text),
            bio = int.Parse(txtBio.Text),
            geografy = int.Parse(txtGeo.Text) 
        };
            ConnectHelper.students.Add(price);
            this.Close();
        }
    }
}
